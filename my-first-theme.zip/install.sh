#!/bin/bash

# Name of your theme folder
THEME_NAME="My-first-theme"
THEME_DIR="/boot/grub/themes/$THEME_NAME"

echo "------------------------------------------"
echo "Installing GRUB Theme: $THEME_NAME"
echo "------------------------------------------"

# Check for root privileges
if [[ $EUID -ne 0 ]]; then
   echo "Please run this script with sudo: sudo ./install.sh"
   exit 1
fi

# Create target directory if it doesn't exist
mkdir -p /boot/grub/themes/

# Copy files (from current folder to system)
echo "Copying files to $THEME_DIR..."
# This command handles both: running from inside the folder or from its parent
cp -r ../$THEME_NAME /boot/grub/themes/ 2>/dev/null || cp -r . /boot/grub/themes/$THEME_NAME

# Update GRUB configuration
echo "Activating theme in /etc/default/grub..."
sed -i '/^GRUB_THEME=/d' /etc/default/grub
echo "GRUB_THEME=\"$THEME_DIR/theme.txt\"" >> /etc/default/grub

# Regenerate GRUB config
echo "Regenerating GRUB configuration..."
grub-mkconfig -o /boot/grub/grub.cfg

echo "------------------------------------------"
echo "Done! The theme has been installed."
echo "Please restart your PC to see the changes."
echo "------------------------------------------"
